#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#define sev 17
#define ther 13
///SUBPROGRAME TASK1:
void verifterminator(char *buffer, int *ok)
{
	//printf("%s",buffer);
	char *string, *proiectie, *verif, *sirt;
	string = (char *)malloc((strlen(buffer) + 1) * sizeof(char));
	proiectie = (char *)malloc((strlen(buffer) + 1) * sizeof(char));
	verif = (char *)malloc((strlen(buffer) + 1) * sizeof(char));

	strcpy(string, buffer);
	char sep[] = "/";
	char *p = strtok(string, sep);

	strcpy(verif, p);

	int num = 1;
	while (p) {
		strcpy(proiectie, p);
		if (num == 1) {
			char r;
			r = '0';
			for (int j = 0; j < 9; j++) {
				if (strchr(p, r))
					*ok = 1;
				r++;
			}
			int var = 0;
			if (strstr(p, "."))
				var = 1;
			if (strstr(p, ".com")) {
				p = strstr(p, ".com");
				//printf("%s\n",p);
				if (p) {
					p[0] = 'M';
					//printf("%s\n",p);
				if (strstr(p, ".")) { ///are 2 domenii
					//printf("%s\n",p);
					if (var == 1)
						*ok = 1;
					}
				}
			}
		}
		if (num == 2) {
			if (strstr(p, "bins"))
				*ok = 1;
		}
		p = strtok(NULL, sep);
		num++;
	}
	if (strstr(buffer, "=com"))
		*ok = 1;
	if (strstr(buffer, "login"))
		*ok = 1;
	if (strstr(buffer, "mod_"))
		*ok = 1;
	if (strstr(buffer, "com.") || strstr(proiectie, ".exe"))
		*ok = 1;
	if (strstr(proiectie, ".bin") || strstr(proiectie, "Mozi.m"))
		*ok = 1;
	if (strstr(proiectie, ".doc") || strstr(proiectie, ".i"))
		*ok = 1;
	if (strstr(proiectie, ".css"))
		*ok = 1;
	if (strstr(proiectie, ".js") || strstr(proiectie, ".arm"))
		*ok = 1;
	if (strcmp(verif, buffer) == 0 || strstr(proiectie, ".pdf"))
		*ok = 1;
	if (strstr(buffer, "'")) // e safe
		*ok = 0;
	if (strstr(buffer, ".html")) // e safe
		*ok = 0;
	//if (strstr(buffer, ".pdf")) // e safe
		//*ok = 0;

	if (verif)
		free(verif);
	if (string)
		free(string);
	if (proiectie)
		free(proiectie);
	//printf("%s",proiectie);
}

void verifbaza(char *buffer, int *ok)
{
    //printf("test");
	FILE *fin;
	fin = fopen("data/urls/domains_database", "r");

	char *citire;
	citire = (char *)malloc(5511 * sizeof(char));
	while (fgets(citire, 5511, fin)) {
		citire[strlen(citire) - 1] = '\0';
		if (strstr(buffer, citire)) {
			//printf("%s\n",citire);
			*ok = 1;
			break;
		}
	}

	if (citire)
		free(citire);
	//*ok=0;
	fclose(fin);
}

void soltask1(char *buffer, int *ok)
{
	///recunoastem daca are la final .exe sau cv
	///verificam daca e in baza de date
	int semafor = 0;
	verifterminator(buffer, &semafor);
	verifbaza(buffer, &semafor);
	*ok = semafor;
}

void task1(void)
{
	FILE *fin, *fout;

	fout = fopen("urls-predictions.out", "w");
	fin = fopen("data/urls/urls.in", "r");

	char *buffer = NULL;
	int ok;
	///task1
	buffer = (char *)malloc(5511 * sizeof(char));
	while (fgets(buffer, 5511, fin)) {
		ok = 0;
		//printf("%s",buffer);
		soltask1(buffer, &ok);
		fprintf(fout, "%d\n", ok);
	}

	if (buffer)
		free(buffer);
	///task2

	fclose(fout);
	fclose(fin);
}

///--------------SUBPROGRAME TASK2:-------------////
void verifflowdurat(char *buffer, int *ok)
{
	//printf("%s",buffer);
	char *string, *proiectie, *verif;
	string = (char *)malloc((strlen(buffer) + 1) * sizeof(char));
	proiectie = (char *)malloc((strlen(buffer) + 1) * sizeof(char));
	verif = (char *)malloc((strlen(buffer) + 1) * sizeof(char));

	strcpy(string, buffer);
	char sep[] = ",";
	char *p = strtok(string, sep);

	strcpy(verif, p);

	int semafor = 0;
	int num = 1;
	int payload = 0;
	while (p) {
		strcpy(proiectie, p);
		if (num == 3) {
			if (strcmp(p, "184.0.48.169") == 0) { /// response_ip
				*ok = 0;// e safe
				break;
			}
			if (strcmp(p, "184.0.48.255") == 0) { /// response_ip
				*ok = 1;// e safe
				break;
			}
			if (strcmp(p, "184.0.48.171") == 0) { /// response_ip
				*ok = 0;// e safe
				break;
			}
			if (strcmp(p, "255.255.255.255") == 0) { /// response_ip
				*ok = 0;// e safe
				break;
			}
		}
		if (num == 5) {
			///if (strstr(p, "00:00:02")) { ///daca e mai mare decat 00:00:01
				//printf("merge\n");
				//*ok = 1;
		///00:00:01 -> 8 caractere
			for (int j = 0; j <= 7; j++)
				verif[j] = p[j + 7];
			verif[8] = '\0';
			///printf("%s\n",verif);
			if (strcmp(verif, "00:00:01") >= 0) {
				//printf("da\n");
				//*ok=1;
				semafor = 1;
			}
			if (strcmp(verif, "00:00:00") == 0) {
				//printf("da\n");
				//*ok=1;
				payload = 1;
			}
		}
		if (num == sev && payload == 1) {
			if (strcmp(p, "39") >= 0)
				*ok = 1;
		}
		if (num == ther && semafor == 1) {
			if (strcmp(p, "0") > 0)
				*ok = 1;
		}
		p = strtok(NULL, sep);
		num++;
	}

	if (verif)
		free(verif);
	if (string)
		free(string);
	if (proiectie)
		free(proiectie);
}

void soltask2(char *buffer, int *ok)
{
	///recunoastem daca are la final .exe sau cv
	///verificam daca e in baza de date
	int semafor = 0;
	verifflowdurat(buffer, &semafor);
	//verifFlowPay(buffer, &semafor);
	*ok = semafor;
}

void task2(void)
{
	FILE *fin, *fout;

	fout = fopen("traffic-predictions.out", "w");
	fin = fopen("data/traffic/traffic.in", "r");

	char *buffer = NULL;
	int ok;

	buffer = (char *)malloc(5511 * sizeof(char));
	fgets(buffer, 5511, fin);
	while (fgets(buffer, 5511, fin)) {
		ok = 0;
		//printf("%s",buffer);
		soltask2(buffer, &ok);
		fprintf(fout, "%d\n", ok);
		///printf("%s",buffer);
	}

	if (buffer)
		free(buffer);

	fclose(fout);
	fclose(fin);
}

int main(void)
{
	task1();
	task2();
	///printf("%d\n",GLOBAL);
	return 0;
}
